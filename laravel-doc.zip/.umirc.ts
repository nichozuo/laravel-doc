import { defineConfig } from 'umi';

export default defineConfig({
  nodeModulesTransform: {
    type: 'none',
  },
  fastRefresh: {},
  dynamicImport: {},
  proxy: {
    '/api': {
      target: 'http://192.168.0.234:8000',
      changeOrigin: true,
    },
  },
});
