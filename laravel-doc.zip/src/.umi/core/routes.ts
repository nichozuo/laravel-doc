// @ts-nocheck
import React from 'react';
import { ApplyPluginsType, dynamic } from '/Users/zuowenbo/Sources/nichozuo/laravel-doc/node_modules/umi/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';

export function getRoutes() {
  const routes = [
  {
    "path": "/",
    "component": dynamic({ loader: () => import(/* webpackChunkName: 'layouts__index' */'@/layouts/index.tsx')}),
    "routes": [
      {
        "path": "/",
        "exact": true,
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__index' */'@/pages/index.tsx')})
      },
      {
        "path": "/modules",
        "exact": true,
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__modules' */'@/pages/modules.tsx')})
      },
      {
        "path": "/readme",
        "exact": true,
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__readme' */'@/pages/readme.tsx')})
      }
    ]
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
