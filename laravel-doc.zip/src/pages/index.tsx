export default () => {
  return <h1>欢迎使用本系统</h1>;
};
