export const API = {
  getMenu: 'home/get_menu',
  getContent: 'home/get_content',
};
